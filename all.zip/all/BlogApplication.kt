package com.example.androidlab

import android.app.Application
import androidx.room.Room
import com.example.androidlab.data.local.BlogDatabase
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BlogApplication : Application() {


}