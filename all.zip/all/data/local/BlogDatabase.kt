package com.example.androidlab.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.androidlab.data.local.dao.BlogPostDao
import com.example.androidlab.data.local.entity.BlogPostEntity


@Database(
    entities = [BlogPostEntity::class],
    version = 1,
    exportSchema = false
)
abstract class BlogDatabase : RoomDatabase() {
    abstract fun blogPostDao(): BlogPostDao
}