package com.example.androidlab.di


import android.content.Context
import androidx.room.Room
import com.example.androidlab.data.local.BlogDatabase
import com.example.androidlab.data.local.dao.BlogPostDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): BlogDatabase =
        Room.databaseBuilder(
            context,
            BlogDatabase::class.java,
            "blog_database"
        ).build()

    @Provides
    @Singleton
    fun provideBlogPostDao(db: BlogDatabase): BlogPostDao = db.blogPostDao()
}