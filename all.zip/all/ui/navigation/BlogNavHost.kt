package com.example.androidlab.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.navigation
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.androidlab.ui.blog.BlogViewModel
import com.example.androidlab.ui.blog.detail.BlogDetailScreen
import com.example.androidlab.ui.blog.edit.BlogEditScreen
import com.example.androidlab.ui.blog.list.BlogListScreen
import com.example.androidlab.ui.home.HomeScreen
import com.example.androidlab.ui.myinfo.MyInfoScreen
import com.example.androidlab.ui.myinfo.MyInfoViewModel

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object MyInfo : Screen("my_info")
    object BlogList : Screen("blog_list")

    object BlogGraph : Screen("blog_graph")

    object BlogEdit : Screen("blog_edit?postId={postId}") {
        fun createRoute(postId: Long? = null) =
            if (postId != null) "blog_edit?postId=$postId" else "blog_edit"
    }
    object BlogDetail : Screen("blog_detail/{postId}") {
        fun createRoute(postId: Long) = "blog_detail/$postId"
    }
}


@Composable
fun BlogNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = Screen.Home.route
    ) {
        composable(Screen.Home.route) {

            val myInfoViewModel: MyInfoViewModel = hiltViewModel()

            HomeScreen(
                viewModel = myInfoViewModel,
                onNavigateToMyInfo = { navController.navigate(Screen.MyInfo.route) },
                onNavigateToBlogList = { navController.navigate(Screen.BlogList.route) }
            )
        }

        composable(Screen.MyInfo.route) {
            val myInfoViewModel: MyInfoViewModel = hiltViewModel()
            MyInfoScreen(

                viewModel = myInfoViewModel,
                onBack = { navController.popBackStack() }
            )
        }

        navigation(
            startDestination = Screen.BlogList.route,
            route = Screen.BlogGraph.route
        ) {
            composable(Screen.BlogList.route) { backStackEntry ->
                val parentEntry = remember(backStackEntry) {
                    navController.getBackStackEntry(Screen.BlogGraph.route)
                }
                val blogViewModel: BlogViewModel = hiltViewModel(parentEntry)

                BlogListScreen(
                    viewModel = blogViewModel,
                    onNavigateToBlogDetail = { postId ->
                        navController.navigate(Screen.BlogDetail.createRoute(postId))
                    },
                    onNavigateToBlogEdit = {
                        navController.navigate(Screen.BlogEdit.createRoute())
                    },
                    onBack = {
                        navController.popBackStack(
                            route = Screen.BlogGraph.route,
                            inclusive = true
                        )
                    }
                )
            }

            composable(
                route = Screen.BlogEdit.route,
                arguments = listOf(
                    navArgument("postId") {
                        type = NavType.LongType
                        defaultValue = -1L
                    }
                )
            ) { backStackEntry ->
                val postId = backStackEntry.arguments?.getLong("postId") ?: -1L

                val productGraphEntry = remember(backStackEntry) {
                    navController.getBackStackEntry(Screen.BlogGraph.route)
                }
                val blogViewModel: BlogViewModel = hiltViewModel(productGraphEntry)
                BlogEditScreen(
                    viewModel = blogViewModel,
                    postId = if (postId == -1L) null else postId,
                    onBack = { navController.popBackStack() },
                    onSaved = { navController.popBackStack() }
                )
            }

            composable(
                route = Screen.BlogDetail.route,
                arguments = listOf(
                    navArgument("postId") { type = NavType.LongType }
                )
            ) { backStackEntry ->
                val postId = backStackEntry.arguments?.getLong("postId") ?: return@composable

                val productGraphEntry = remember(backStackEntry) {
                    navController.getBackStackEntry(Screen.BlogGraph.route)
                }
                val blogViewModel: BlogViewModel = hiltViewModel(productGraphEntry)
                BlogDetailScreen(
                    viewModel = blogViewModel,
                    postId = postId,
                    onBack = { navController.popBackStack() },
                    onEdit = { navController.navigate(Screen.BlogEdit.createRoute(postId)) },
                    onDeleted = { navController.popBackStack() }
                )
            }
        }


    }
}