// MyAIDLInterface.aidl
package com.example.more_aidl_outer;

// Declare any non-default types here with import statements

interface MyAIDLInterface {
    int getMaxDuiration();
        void start();
        void stop();
}