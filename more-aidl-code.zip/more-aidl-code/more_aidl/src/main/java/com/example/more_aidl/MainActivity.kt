package com.example.more_aidl

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.more_aidl.ui.theme.AndroidLabTheme
import com.example.more_aidl_outer.MyAIDLInterface
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    // ── AIDL ──────────────────────────────────────────────
    private var aidlService: MyAIDLInterface? = null
    private var aidlBound = false

    private val aidlConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            aidlService = MyAIDLInterface.Stub.asInterface(service)
            aidlBound = true
        }
        override fun onServiceDisconnected(name: ComponentName) {
            aidlService = null
            aidlBound = false
        }
    }

    // ── Messenger ─────────────────────────────────────────
    private var messengerService: Messenger? = null
    private var messengerBound = false
    var onDurationReceived: ((Int) -> Unit)? = null

    private val replyMessenger = Messenger(object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                10 -> {
                    val bundle = msg.obj as? Bundle
                    val duration = bundle?.getInt("duration") ?: 0
                    onDurationReceived?.invoke(duration)
                }
            }
        }
    })

    private val messengerConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, service: IBinder) {
            messengerService = Messenger(service)
            messengerBound = true
        }
        override fun onServiceDisconnected(name: ComponentName) {
            messengerService = null
            messengerBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // AIDL 서비스 bind
        Intent("com.example.ch5_outer.ACTION_SERVICE_AIDL").also { intent ->
            intent.setPackage("com.example.more_aidl_outer")
            bindService(intent, aidlConnection, Context.BIND_AUTO_CREATE)
        }

        // Messenger 서비스 bind
        Intent("com.example.ch5_outer.ACTION_SERVICE_Messenger").also { intent ->
            intent.setPackage("com.example.more_aidl_outer")
            bindService(intent, messengerConnection, Context.BIND_AUTO_CREATE)
        }

        enableEdgeToEdge()
        setContent {
            AndroidLabTheme {
                MusicPlayerScreen(
                    onAidlStart = {
                        aidlService?.start()
                        aidlService?.maxDuiration ?: 0
                    },
                    onAidlStop = { aidlService?.stop() },
                    onAidlDuration = { aidlService?.maxDuiration ?: 0 },
                    onMessengerStart = { callback ->
                        onDurationReceived = callback
                        val msg = Message.obtain(null, 10)
                        msg.replyTo = replyMessenger
                        messengerService?.send(msg)
                    },
                    onMessengerStop = {
                        val msg = Message.obtain(null, 20)
                        messengerService?.send(msg)
                    }
                )

            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (aidlBound) unbindService(aidlConnection)
        if (messengerBound) unbindService(messengerConnection)
    }
}

@Composable
fun MusicPlayerScreen(
    onAidlStart: () -> Int,
    onAidlStop: () -> Unit,
    onAidlDuration: () -> Int,
    onMessengerStart: ((Int) -> Unit) -> Unit,
    onMessengerStop: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D0D0D))
    ) {
        // 위쪽 절반 – AIDL
        PlayerPanel(
            title = "AIDL Service",
            accentColor = Color(0xFF00E5FF),
            modifier = Modifier.weight(1f),
            onStart = onAidlStart,
            onStop = onAidlStop,
            getDuration = onAidlDuration,
            useCallback = false,
            onStartWithCallback = null
        )

        Divider(color = Color(0xFF222222), thickness = 1.dp)

        // 아래쪽 절반 – Messenger
        PlayerPanel(
            title = "Messenger Service",
            accentColor = Color(0xFFFF6B35),
            modifier = Modifier.weight(1f),
            onStart = { 0 },
            onStop = onMessengerStop,
            getDuration = { 0 },
            useCallback = true,
            onStartWithCallback = onMessengerStart
        )
    }
}

@Composable
fun PlayerPanel(
    title: String,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onStart: () -> Int,
    onStop: () -> Unit,
    getDuration: () -> Int,
    useCallback: Boolean,
    onStartWithCallback: ((((Int) -> Unit) -> Unit))?
) {
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableStateOf(0) }      // ms
    var elapsed by remember { mutableStateOf(0) }       // ms
    val progress = if (duration > 0) elapsed.toFloat() / duration else 0f
    val animatedProgress by animateFloatAsState(
        targetValue = progress,
        animationSpec = tween(500),
        label = "progress"
    )

    // 재생 중일 때 elapsed 를 1초마다 증가
    LaunchedEffect(isPlaying) {
        if (isPlaying) {
            while (isPlaying) {
                delay(1000)
                elapsed = (elapsed + 1000).coerceAtMost(duration)
                if (elapsed >= duration && duration > 0) {
                    isPlaying = false
                    elapsed = 0
                }
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF111111),
                        Color(0xFF0A0A0A)
                    )
                )
            )
            .padding(horizontal = 28.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // 제목
        Text(
            text = title,
            color = accentColor,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )

        // 재생 상태 표시
        Text(
            text = if (isPlaying) "▶  Playing" else "■  Stopped",
            color = if (isPlaying) Color.White else Color(0xFF555555),
            fontSize = 22.sp,
            fontWeight = FontWeight.Light
        )

        // Progress bar
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(50)),
                color = accentColor,
                trackColor = Color(0xFF2A2A2A)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formatMs(elapsed),
                    color = Color(0xFF777777),
                    fontSize = 11.sp
                )
                Text(
                    text = formatMs(duration),
                    color = Color(0xFF777777),
                    fontSize = 11.sp
                )
            }
        }

        // 버튼 행
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // START 버튼
            Button(
                onClick = {
                    if (!isPlaying) {
                        elapsed = 0
                        if (useCallback && onStartWithCallback != null) {
                            onStartWithCallback { dur ->
                                duration = dur
                                isPlaying = true
                            }
                        } else {
                            val dur = onStart()
                            duration = dur
                            isPlaying = true
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = Color.Black
                ),
                enabled = !isPlaying
            ) {
                Text("START", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }

            // STOP 버튼
            OutlinedButton(
                onClick = {
                    if (isPlaying) {
                        onStop()
                        isPlaying = false
                        elapsed = 0
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, accentColor),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = accentColor
                ),
                enabled = isPlaying
            ) {
                Text("STOP", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }
    }
}

private fun formatMs(ms: Int): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return "%d:%02d".format(min, sec)
}